package com.senai.crud.services;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.EstadoDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.models.CategoriaModel;
import com.senai.crud.models.EstadoModel;
import com.senai.crud.models.UsuarioModel;
import com.senai.crud.repositories.EstadoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EstadoService {
    private final EstadoRepository repository;

    public EstadoService(EstadoRepository repository) {
        this.repository = repository;
    }
    public RespostaDto cadastrar(EstadoDto estadoDto){
        EstadoModel estadoModel = new EstadoModel();
         estadoModel.setNome(estadoDto.getNome());
         estadoModel.setSigla(estadoDto.getSigla());

         repository.save(estadoModel);
         RespostaDto resposta = new RespostaDto();
         resposta.setMensagem("sucesso");
         return  resposta;
    }

    public RespostaDto excluir(Long id){

        Optional<EstadoModel> estadoOP = repository.findById(id);

        if (estadoOP.isPresent()){
            repository.delete(estadoOP.get());
            RespostaDto resposta = new  RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("Não foi possível remover o estado id = " + id);
        return resposta ;

    }

    public RespostaDto atualizar(Long id,EstadoDto estadoDto){
        Optional<EstadoModel> estadoOp= repository.findById(id);
        if (estadoOp.isPresent()){
            EstadoModel estado = estadoOp.get();
            estado.setNome(estadoDto.getNome());
            estado.setSigla(estadoDto.getSigla());
            repository.save(estado);
            RespostaDto resposta = new RespostaDto();
            resposta.setMensagem("sucesso");
            return  resposta;

        }
        RespostaDto resposta = new RespostaDto();
        resposta.setMensagem("erro");
        return resposta;
    }

    public List<EstadoDto> obterEstado(){
        List<EstadoDto> listaEstadosDto= new ArrayList<>();
        List<EstadoModel> listaEstadoModel= repository.findAll();
        for (EstadoModel estado: listaEstadoModel){
            EstadoDto estadoDto=new EstadoDto();
            estadoDto.setId(estado.getId());
             estadoDto.setNome(estado.getNome());
             estadoDto.setSigla(estado.getSigla());
             listaEstadosDto.add(estadoDto);
        }
        return listaEstadosDto;
    }

    public EstadoDto obterEstado(Long id){


        EstadoDto estadoDto=new EstadoDto();
        Optional<EstadoModel>estadoOp=repository.findById(id);

        if (estadoOp.isPresent()){
            estadoDto.setId(estadoOp.get().getId());
            estadoDto.setId(estadoOp.get().getId());
            estadoDto.setNome(estadoOp.get().getNome());
            estadoDto.setSigla(estadoOp.get().getSigla());

            return estadoDto;
        }
        return estadoDto;
    }




}
