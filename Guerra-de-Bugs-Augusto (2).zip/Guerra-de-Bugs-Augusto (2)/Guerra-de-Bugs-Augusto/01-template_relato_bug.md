
# 🐞 Relato de Bug

**Projeto:**  
**Aluno que encontrou:**  
**Aluno dona do projeto:**  
**Severidade:** (Crítica | Média | Leve)  
**Componente / Tela:**  

## Passos para reproduzir
1. 
2. 
3. 

### Resultado obtido
(prints, logs, stacktrace)

### Resultado esperado
(descrever o comportamento correto)

## Hipótese de causa-raiz
Possível origem do bug (validação, service, controller, template...)

## Evidência / Print
(anexar imagem)

---
**Status:** (Aberto | Corrigido | Validado)
