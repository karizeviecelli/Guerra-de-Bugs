package com.senai.crud.controllers;

import com.senai.crud.model.Contato;
import com.senai.crud.services.ContatoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ContatoCadastrarController {

    private final ContatoService contatoService;

    @Autowired
    public ContatoCadastrarController(ContatoService contatoService) {
        this.contatoService = contatoService;
    }

    @GetMapping("/contatos/novo")
    public String abrirFormularioCadastro(Model model) {
        if (!model.containsAttribute("contato")) {
            model.addAttribute("contato", new Contato());
        }
        return "contato/cadastrar"; // templates/contato/cadastrar.html
    }

    @PostMapping("/contatos")
    public String salvarContato(@Valid @ModelAttribute("contato") Contato contato,
                                BindingResult bindingResult,
                                RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.contato", bindingResult);
            redirectAttributes.addFlashAttribute("contato", contato);
            return "redirect:/contatos/novo";
        }

        contatoService.salvar(contato);
        redirectAttributes.addFlashAttribute("sucesso", "Contato cadastrado com sucesso!");
        return "redirect:/contatos/listar";
    }
}
