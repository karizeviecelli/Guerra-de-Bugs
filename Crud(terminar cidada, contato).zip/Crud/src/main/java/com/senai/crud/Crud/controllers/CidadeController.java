package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CidadeDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.CidadeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CidadeController {

    CidadeService cidadeService;

    public CidadeController(CidadeService cidadeService) {
        this.cidadeService = cidadeService;
    }

    @PostMapping("/cidade")
    public String cadastrarCidade(CidadeDto cidadeDto) {

        boolean cadastrou = cidadeService.cadastrarCidade(cidadeDto);

        return "redirect:/cidadelista";
    }


    @DeleteMapping("/cidade/{id}")
    public ResponseEntity<SaidaDto> exluirCidade(@PathVariable Long id) {

        SaidaDto saidaDto = cidadeService.excluirCidade(id);

        if (saidaDto.getMensagem().equals("sucesso")) {

            return ResponseEntity.ok().body(saidaDto);
        } else {

            return ResponseEntity.status(HttpStatus.CONFLICT).body(saidaDto);
        }
    }

}
