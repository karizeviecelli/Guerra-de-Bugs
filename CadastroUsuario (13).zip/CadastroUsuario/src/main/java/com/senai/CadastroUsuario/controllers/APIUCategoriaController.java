package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaRequestDTO;
import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.RespostaDto;
import com.senai.CadastroUsuario.services.CategoriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")
public class APIUCategoriaController {

    CategoriaService service;

    public APIUCategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping("/cadastrarCategoria")
    public ResponseEntity <RespostaDto> cadastrarCategoria (@RequestBody CategoriaRequestDTO dados){

          RespostaDto resposta = service.cadastrarCategoria(dados);

        return  ResponseEntity.ok().body(resposta);
    }

    @DeleteMapping("deletarCategoria/{id}")
    public ResponseEntity<RespostaDto> deletarCategoria(@PathVariable long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
    }
    @GetMapping("/listarTodos")
    public ResponseEntity<List<CategoriaResponseDTO>> listarTodos (){
        List<CategoriaResponseDTO> resposta = service.listarCategoria();

       return ResponseEntity.ok().body(resposta);
    }


    @PutMapping("alterarCategoria/{id}")
    public ResponseEntity<RespostaDto> alterarCategoria(@PathVariable long id , @RequestBody CategoriaRequestDTO dados){

        RespostaDto resposta = service.alterarCategoria(id,dados);
        return ResponseEntity.ok().body(resposta);
    }
    @GetMapping("pesquisaCategoria/{id}")
    public ResponseEntity<CategoriaResponseDTO> pesquisaCategoria(@PathVariable long id){

        CategoriaResponseDTO resposta = service.pesquisaCategoria(id);

        return ResponseEntity.ok().body(resposta);
    }
}
