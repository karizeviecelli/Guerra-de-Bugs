package com.senai.crud.Crud.services;


import com.senai.crud.Crud.dtos.EstadoDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.models.EstadoModel;
import com.senai.crud.Crud.repositories.EstadoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EstadoService {

    private final EstadoRepository estadoRepository;

    public EstadoService(EstadoRepository estadoRepository) {
        this.estadoRepository = estadoRepository;
    }

    public boolean cadastrarEstado(EstadoDto estadoDto) {

        EstadoModel novoEstado = new EstadoModel();

        novoEstado.setNome(estadoDto.getNome());
        novoEstado.setSigla(estadoDto.getSigla());

        estadoRepository.save(novoEstado);
        return true;

    }

    public SaidaDto excluirEstado(Long id) {

        SaidaDto saidaDto = new SaidaDto();
        Optional<EstadoModel> estadoModelOptional = estadoRepository.findById(id);

        if (estadoModelOptional.isPresent()) {

            estadoRepository.delete(estadoModelOptional.get());
            saidaDto.setMensagem("sucesso");

            return saidaDto;
        } else {
            return saidaDto;
        }

    }

    public List<EstadoDto> listarEstados() {

        List<EstadoModel> estadoModelList = estadoRepository.findAll();

        List<EstadoDto> listaEstados = new ArrayList<>();
        for (EstadoModel estadoModel : estadoModelList) {

            EstadoDto estadoDto = new EstadoDto();

            estadoDto.setId(estadoModel.getId());
            estadoDto.setNome(estadoModel.getNome());
            estadoDto.setSigla(estadoModel.getSigla());

            listaEstados.add(estadoDto);

        }

        return listaEstados;
    }

    public boolean atualizarEstado(Long id, EstadoDto estadoDto) {

        Optional<EstadoModel> estadoModelOptional = estadoRepository.findById(id);

        if (estadoModelOptional.isEmpty()) {
            return false;
        }

        EstadoModel estadoModel = estadoModelOptional.get();

        estadoModel.setNome(estadoDto.getNome());
        estadoModel.setSigla(estadoDto.getSigla());
        estadoRepository.save(estadoModel);

        return true;

    }

    public EstadoDto buscarEstadoPorId(Long id) {

        EstadoDto estadoDto = new EstadoDto();

        Optional<EstadoModel> estadoModelOptional = estadoRepository.findById(id);

        if (estadoModelOptional.isEmpty()) {

            return estadoDto;

        }

        estadoDto.setId(estadoModelOptional.get().getId());
        estadoDto.setNome(estadoModelOptional.get().getNome());
        estadoDto.setSigla(estadoModelOptional.get().getSigla());

        return estadoDto;


    }


}
