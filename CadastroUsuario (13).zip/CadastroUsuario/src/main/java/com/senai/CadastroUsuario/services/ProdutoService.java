package com.senai.CadastroUsuario.services;

import com.senai.CadastroUsuario.dtos.*;
import com.senai.CadastroUsuario.models.Categoria;
import com.senai.CadastroUsuario.models.Produto;
import com.senai.CadastroUsuario.repositories.CategoriaRepository;
import com.senai.CadastroUsuario.repositories.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    List<Produto> ListaProduto = new ArrayList<Produto>();

    private final ProdutoRepository repository;
    private final CategoriaRepository repositoryCategoria;

    public ProdutoService(ProdutoRepository repository, CategoriaRepository repositoryCategoria) {
        this.repository = repository;
        this.repositoryCategoria = repositoryCategoria;
    }

    public RespostaDto cadastrarProduto(ProdutoRequestDTO dados){



        RespostaDto resposta = new RespostaDto();

      Optional<Categoria>  categoriaOp  = repositoryCategoria.findById(dados.getCategoriaId());

      if(categoriaOp.isPresent()){

          Produto produto = new Produto();
          produto.setNome(dados.getNome());
          produto.setPreco(dados.getPreco());
          produto.setCategoria(categoriaOp.get());



          repository.save(produto);

          ListaProduto.add(produto);
          resposta.setMensagem("Produto cadastrado com sucesso");

          return resposta;

      }
        resposta.setMensagem("Produto não cadastrado ");
        return resposta;
    }

    public RespostaDto deletar(long id){

        RespostaDto resposta = new RespostaDto();


        Optional<Produto> ProdutoOp = repository.findById(id);

        if(ProdutoOp.isPresent()){

            repository.delete(ProdutoOp.get());
            resposta.setMensagem("Produto deletado com sucesso");
            return resposta;
        }
        resposta.setMensagem("Produto não deletado");
        return resposta;
    }

    public RespostaDto alterarProduto (long id , ProdutoResponseDTO dados) {

        RespostaDto resposta = new RespostaDto();

        Optional<Categoria>  categoriaOp  = repositoryCategoria.findById(dados.getCategoriaId());
        Optional<Produto> produtoOp = repository.findById(id);

        if (produtoOp.isPresent() && categoriaOp.isPresent()) {

            Produto produto = produtoOp.get();
            produto.setNome(dados.getNome());
            produto.setPreco(dados.getPreco());
            produto.setCategoria(categoriaOp.get());



            repository.save(produto);
            resposta.setMensagem("Produto alterado com sucesso");
            return resposta;
        }

        resposta.setMensagem("Produto não alterada");
        return resposta;
    }

    public List<ProdutoResponseDTO> ListaProduto() {

        List<ProdutoResponseDTO> listaResposta = new ArrayList<>();

      List<Produto> produtoListagem = repository.findAll();

        for(Produto produto : produtoListagem){

            ProdutoResponseDTO produtoLista = new ProdutoResponseDTO();

            produtoLista.setId(produto.getId());
            produtoLista.setDescricao(produto.getCategoria().getNome());
            produtoLista.setNome(produto.getNome());
            produtoLista.setPreco(produto.getPreco());


            listaResposta.add(produtoLista);

        }

        return listaResposta;
    }

        public ProdutoResponseDTO pesquisaProduto(long id) {

            ProdutoResponseDTO resposta = new ProdutoResponseDTO();

            Optional<Produto> produtoOp = repository.findById(id);

            if (produtoOp.isPresent()) {

                resposta.setId(produtoOp.get().getId());
                resposta.setNome(produtoOp.get().getNome());
                resposta.setPreco(produtoOp.get().getPreco());
                resposta.setCategoriaId(produtoOp.get().getCategoria().getId());


                return resposta;

            }

            return resposta;
        }
/*
    public List<ProdutoResponseDTO> listaProdutoCategoria (Long id){
        List<ProdutoResponseDTO> listaResposta = new ArrayList<>();

        for(Produto listagem : ListaProduto){

            if(listagem.getCategoriaId().equals(id)){

                ProdutoResponseDTO produtoLista = new ProdutoResponseDTO();
                produtoLista.setId(listagem.getId());
                produtoLista.setNome(listagem.getNome());
                produtoLista.setPreco(listagem.getPreco());
                produtoLista.setCategoriaId(listagem.getCategoriaId());

                listaResposta.add(produtoLista);
            }
        }

        return listaResposta;
    }

 */
}
