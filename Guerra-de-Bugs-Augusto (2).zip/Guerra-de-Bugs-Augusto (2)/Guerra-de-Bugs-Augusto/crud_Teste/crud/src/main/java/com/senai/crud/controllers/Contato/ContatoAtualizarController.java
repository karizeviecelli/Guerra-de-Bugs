package com.senai.crud.controllers;

import com.senai.crud.model.Contato;
import com.senai.crud.services.ContatoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class ContatoAtualizarController {

    private final ContatoService contatoService;

    @Autowired
    public ContatoAtualizarController(ContatoService contatoService) {
        this.contatoService = contatoService;
    }

    @GetMapping("/contatos/{id}/editar")
    public String editarContato(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<Contato> contatoOpt = contatoService.buscarPorId(id);

        if (contatoOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("erro", "Contato não encontrado!");
            return "redirect:/contatos/listar";
        }

        model.addAttribute("contato", contatoOpt.get());
        return "contato/editar"; // templates/contato/editar.html
    }

    @PostMapping("/contatos/{id}/atualizar")
    public String atualizarContato(@PathVariable Long id,
                                   @Valid @ModelAttribute("contato") Contato contato,
                                   BindingResult bindingResult,
                                   RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            return "contato/editar";
        }

        contato.setId(id);
        contatoService.salvar(contato);
        redirectAttributes.addFlashAttribute("sucesso", "Contato atualizado com sucesso!");
        return "redirect:/contatos/listar";
    }
}
