package com.senai.crud.controllers.cidade;

import com.senai.crud.model.Cidade;
import com.senai.crud.services.CidadeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CidadeCadastroController {

    private final CidadeService cidadeService;

    @Autowired
    public CidadeCadastroController(CidadeService cidadeService) {
        this.cidadeService = cidadeService;
    }

    /**
     * Exibe o formulário de cadastro de cidade.
     * Endpoint: GET /cidades/nova
     */
    @GetMapping("/cidades/nova")
    public String abrirFormularioCadastro(Model model) {
        // Se o modelo não tiver uma cidade (em caso de erro de validação, por exemplo),
        // adiciona uma nova cidade vazia para o formulário.
        if (!model.containsAttribute("cidade")) {
            model.addAttribute("cidade", new Cidade());
        }
        return "cidade/cadastrar"; // Retorna o template Thymeleaf: templates/cidade/cadastrar.html
    }

    /**
     * Salva uma nova cidade após o envio do formulário.
     * Endpoint: POST /cidades
     */
    @PostMapping("/cidades")
    public String salvarCidade(@Valid @ModelAttribute("cidade") Cidade cidade,
                               BindingResult bindingResult,
                               RedirectAttributes redirectAttributes) {

        // Caso haja erros de validação, redireciona de volta ao formulário
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.cidade", bindingResult);
            redirectAttributes.addFlashAttribute("cidade", cidade);
            return "redirect:/cidades/nova";
        }

        // Salva no banco de dados
        cidadeService.salvar(cidade);

        // Mensagem de sucesso via flash
        redirectAttributes.addFlashAttribute("sucesso", "Cidade cadastrada com sucesso!");

        // Redireciona para a listagem de cidades
        return "redirect:/cidades";
    }
}
