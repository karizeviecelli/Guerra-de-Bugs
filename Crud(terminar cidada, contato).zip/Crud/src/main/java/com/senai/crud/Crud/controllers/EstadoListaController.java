package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.EstadoDto;
import com.senai.crud.Crud.services.EstadoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class EstadoListaController {

    private final EstadoService estadoService;

    public EstadoListaController(EstadoService estadoService) {
        this.estadoService = estadoService;
    }

    @GetMapping("/estadolista")
    public String viewEstadosLista(Model model) {

        List<EstadoDto> listaEstados = estadoService.listarEstados();

        model.addAttribute("estadoLista", listaEstados);
        return "estadolista";
    }
}
