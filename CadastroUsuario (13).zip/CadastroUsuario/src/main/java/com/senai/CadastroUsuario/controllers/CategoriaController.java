package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaRequestDTO;
import com.senai.CadastroUsuario.dtos.ProdutoRequestDTO;
import com.senai.CadastroUsuario.dtos.ProdutoResponseDTO;
import com.senai.CadastroUsuario.dtos.RespostaDto;
import com.senai.CadastroUsuario.services.CategoriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CategoriaController {

    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping("/categoria")
    public String cadastrar(@ModelAttribute("categoriaDto")CategoriaRequestDTO categoriaDto ){

        RespostaDto resposta = service.cadastrarCategoria(categoriaDto);


        return "redirect:/categorialista";
    }

    @PostMapping("/categoria/{id}")
    public String atualizar(@ModelAttribute("categoriaDto") CategoriaRequestDTO categoriaDTO, @PathVariable Long id){

        RespostaDto resposta = service.alterarCategoria(id, categoriaDTO);

        return "redirect:/categorialista";
    }

    @DeleteMapping("categoria/{id}")
    public ResponseEntity<RespostaDto> deletarCategoria(@PathVariable long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
    }
}
