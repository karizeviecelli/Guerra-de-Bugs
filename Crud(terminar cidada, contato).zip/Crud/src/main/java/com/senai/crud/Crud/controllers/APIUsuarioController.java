package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.EntradaDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.dtos.UsuarioDto;
import com.senai.crud.Crud.services.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")
public class APIUsuarioController {

    private UsuarioService service;

    public APIUsuarioController(UsuarioService service) {
        this.service = service;
    }

    @PostMapping("/usuario")
    public ResponseEntity<SaidaDto> cadastrar(@RequestBody EntradaDto dados) {

        SaidaDto resposta = service.cadastrar(dados);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("Usuário cadastrado com sucesso");
        } else {
            resposta.setMensagem("Não foi possivel cadastrar o usuário");
        }
        return ResponseEntity.ok().body(resposta);
    }


    @GetMapping("/usuarios/{id}")
    public ResponseEntity<Object> buscarUsuario(@PathVariable Long id) {

        UsuarioDto usuarioDto = service.buscarUsuario(id);

        if (usuarioDto == null) {
            SaidaDto resposta = new SaidaDto();
            resposta.setMensagem("Usuário não encontrado");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        } else {
            return ResponseEntity.ok().body(usuarioDto);
        }

    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<UsuarioDto>> listarUsuarios() {

        List<UsuarioDto> listaDeUsuarios = service.listarUsuarios();

        return ResponseEntity.ok().body(listaDeUsuarios);
    }


    @PutMapping("/usuario/{id}")
    public ResponseEntity<SaidaDto> atualizar(@PathVariable Long id, @RequestBody EntradaDto dados) {

        SaidaDto resposta = service.atualizar(id, dados);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("Os dados do usuário foram atualizados");
        } else {
            resposta.setMensagem("Não foi possivel atualizar os dados");
        }
        return ResponseEntity.ok().body(resposta);
    }

    @DeleteMapping("/usuario/{id}")
    public ResponseEntity<SaidaDto> excluir(@PathVariable Long id) {

        SaidaDto resposta = service.excluirUsuario(id);

        if (resposta.getMensagem().equals("sucesso")) {

            resposta.setMensagem("Usuário exluido com sucesso");

        } else if (resposta.getMensagem().equals("erro")) {

            resposta.setMensagem("Não foi possivel exluir o usuário");
        }
        return ResponseEntity.ok().body(resposta);
    }
}
