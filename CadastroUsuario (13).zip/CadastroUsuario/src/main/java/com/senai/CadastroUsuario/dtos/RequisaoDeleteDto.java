package com.senai.CadastroUsuario.dtos;

public class RequisaoDeleteDto {

    private Long id;

    public RequisaoDeleteDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "RequisaoDeleteDto{" +
                "id=" + id +
                '}';
    }
}
