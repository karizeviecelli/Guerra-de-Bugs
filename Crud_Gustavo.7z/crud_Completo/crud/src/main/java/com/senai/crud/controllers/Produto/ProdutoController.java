package com.senai.crud.controllers.Produto;

import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.ProdutoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.*;

@Controller
public class ProdutoController {
    private  final ProdutoService service;
    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/produto")
    public String cadastrar(@ModelAttribute("produtoDto") ProdutoDto produtoDto){
        RespostaDto mensagem = service.cadastrar(produtoDto);
        return "redirect:/produtolista";
    }
    @PostMapping("/produto/{id}")
    public String atualizar(@ModelAttribute("produtoDto") ProdutoDto produtoDto, @PathVariable Long id){

        service.atualizar(id,produtoDto);

        return "redirect:/produtolista";
    }
    @DeleteMapping("/produto/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){
        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("produto excluido com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }
}
