package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.ProdutoResponseDTO;
import com.senai.CadastroUsuario.models.Produto;
import com.senai.CadastroUsuario.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ProdutoListaController {

    private final ProdutoService serivice;

    public ProdutoListaController(ProdutoService serivice) {
        this.serivice = serivice;
    }

    @GetMapping("/produtolista")
    public String listapProduto(Model model){

        List<ProdutoResponseDTO> listagemDto = serivice.ListaProduto();
        model.addAttribute("listagemDto" , listagemDto);
        return "produtolista";
    }
}
