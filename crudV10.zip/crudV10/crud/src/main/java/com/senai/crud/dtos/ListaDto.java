package com.senai.crud.dtos;

public class ListaDto {

    private Long id;
    private String nome;

    public ListaDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ListaDto(Long id, String nome) {
        this.id = id;
        this.nome = nome;


    }
}
