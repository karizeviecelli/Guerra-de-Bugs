package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.UsuarioDto;
import com.senai.crud.Crud.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class UsuarioAtualizarController {

    UsuarioService service;

    public UsuarioAtualizarController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/usuarioatualizar/{id}")
    public String viewUsuarioAtualizar(@PathVariable Long id, Model model) {

        UsuarioDto usuarioDto = service.buscarUsuario(id);

        model.addAttribute("usuarioDto", usuarioDto);
        return "usuarioatualizar";
    }
}
