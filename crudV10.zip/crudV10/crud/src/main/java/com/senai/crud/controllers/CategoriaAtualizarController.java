package com.senai.crud.controllers;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class CategoriaAtualizarController {

    private final CategoriaService service;

    public CategoriaAtualizarController(CategoriaService service) {
        this.service = service;
    }

    // Mostrar formulário para atualizar categoria
    @GetMapping("/categoriaatualizar/{id}")
    public String mostrarFormulario(@PathVariable Long id, Model model) {
        CategoriaDto categoriaDto = service.obterCategoria(id);
        model.addAttribute("categoriaDto", categoriaDto);
        return "categoriaatualizar";  // Nome do template Thymeleaf
    }

    // Receber dados do formulário e atualizar categoria
    @PostMapping("/categoriaatualizar/{id}")
    public String atualizarCategoria(@PathVariable Long id, @ModelAttribute("categoriaDto") CategoriaDto categoriaDto) {
        service.atualizar(id, categoriaDto);
        return "redirect:/categorialista"; // Após atualizar, redireciona para lista
    }
}
