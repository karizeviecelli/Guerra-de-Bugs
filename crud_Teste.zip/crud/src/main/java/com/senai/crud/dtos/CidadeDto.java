package com.senai.crud.dtos;

public class CidadeDto {
    private Long id;
    private String nome;
    private Long estadoId;

    public CidadeDto() {
    }

    public CidadeDto(Long id, String nome, Long estadoId) {
        this.id = id;
        this.nome = nome;
        this.estadoId = estadoId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getEstadoId() {
        return estadoId;
    }

    public void setEstadoId(Long estadoId) {
        this.estadoId = estadoId;
    }
}
