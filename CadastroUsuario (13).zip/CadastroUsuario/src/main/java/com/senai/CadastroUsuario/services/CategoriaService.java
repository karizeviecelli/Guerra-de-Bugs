package com.senai.CadastroUsuario.services;

import com.senai.CadastroUsuario.dtos.CategoriaRequestDTO;
import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.RespostaDto;
import com.senai.CadastroUsuario.models.Categoria;
import com.senai.CadastroUsuario.repositories.CategoriaRepository;
import com.senai.CadastroUsuario.repositories.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {
    List<Categoria> ListaCategoria = new ArrayList<Categoria>();

    private final CategoriaRepository repository;

    public CategoriaService(CategoriaRepository repository) {
        this.repository = repository;
    }

    public RespostaDto cadastrarCategoria (CategoriaRequestDTO dados){

        Categoria categoria = new Categoria();
        RespostaDto resposta = new RespostaDto();

        categoria.setNome(dados.getNome());

        repository.save(categoria);

        ListaCategoria.add(categoria);

        resposta.setMensagem("Categoria cadastrada com sucesso");

        return resposta;
    }

    public RespostaDto deletar(long id){

        RespostaDto resposta = new RespostaDto();

        Optional<Categoria> categoriaOp = repository.findById(id);

        if(categoriaOp.isPresent()){

            repository.delete(categoriaOp.get());
            resposta.setMensagem("Categoria deletada com sucesso");
            return resposta;
        }
        resposta.setMensagem("Categoria não deletada");
        return resposta;
    }

    public List<CategoriaResponseDTO> listarCategoria(){

        List<CategoriaResponseDTO> listaResposta = new ArrayList<>();

       List<Categoria> listaCategoriaModel =  repository.findAll();

        for(Categoria lista : listaCategoriaModel){

            CategoriaResponseDTO categoria = new CategoriaResponseDTO();

            categoria.setId(lista.getId());
            categoria.setNome(lista.getNome());

            listaResposta.add(categoria);
        }
        return listaResposta;
    }

    public RespostaDto alterarCategoria (long id , CategoriaRequestDTO dados){

        RespostaDto resposta = new RespostaDto();

      Optional<Categoria> categoriaOp = repository.findById(id);

      if(categoriaOp.isPresent()){

          Categoria categoria = categoriaOp.get();
          categoria.setNome(dados.getNome());

          repository.save(categoria);
          resposta.setMensagem("Categoria alterada com sucesso");
          return resposta;
      }

      resposta.setMensagem("Categoria não alterada");
      return resposta;
    }

    public CategoriaResponseDTO pesquisaCategoria(long id){

        CategoriaResponseDTO resposta = new CategoriaResponseDTO();

       Optional<Categoria> categoriaOp = repository.findById(id);

       if(categoriaOp.isPresent()){

           resposta.setId(categoriaOp.get().getId());
           resposta.setNome(categoriaOp.get().getNome());

           return resposta;

       }

       return resposta;
    }


}
