package com.senai.crud.controllers.Produto;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class ProdutoListaController {
    private final ProdutoService service;
    private final CategoriaService categoriaService;

    public ProdutoListaController(ProdutoService service, CategoriaService categoriaService) {
        this.service = service;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/produtolista")
    public String viewProdutoLista(Model model){
        List<CategoriaDto> categoriaDto=categoriaService.obterCategorias();
        List<ProdutoDto> listaDto=service.obterProdutos();
        model.addAttribute("listaDto",listaDto);
        model.addAttribute("categoriaDto",categoriaDto);
        return "produtolista";
    }
}
