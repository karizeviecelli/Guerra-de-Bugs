package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.services.CategoriaService;
import com.senai.crud.Crud.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ProdutoAtualizarController {

    private final ProdutoService produtoService;
    private final CategoriaService categoriaService;

    public ProdutoAtualizarController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/produtoatualizar/{id}")
    public String viewCadastrarProduto(Model model, @PathVariable Long id) {

        ProdutoDto produtoDto = produtoService.buscarProduto(id);
        List<CategoriaDto> listaCategorias = categoriaService.listarCategorias();

        model.addAttribute("produtoDto", produtoDto);
        model.addAttribute("listaCategoria", listaCategorias);
        return "produtoatualizar";
    }

}
