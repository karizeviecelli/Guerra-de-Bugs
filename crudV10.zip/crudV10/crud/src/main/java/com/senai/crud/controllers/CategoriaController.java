package com.senai.crud.controllers;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.CategoriaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/categoria")
public class CategoriaController {

    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    //-- Criar categoria (POST)
    @PostMapping
    public String cadastrar(@ModelAttribute("categoriaDto") CategoriaDto categoriaDto) {
        RespostaDto resposta = service.cadastrar(categoriaDto);
        return "redirect:/categorialista";  // Ajuste para sua URL real da lista
    }

    //-- Excluir categoria (DELETE via AJAX, por exemplo)
    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id) {
        RespostaDto resposta = service.excluir(id);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("Categoria excluída com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }

    //-- Exibir formulário para atualizar categoria
    @GetMapping("/atualizar/{id}")
    public String exibirFormularioAtualizar(@PathVariable Long id, Model model) {
        CategoriaDto categoriaDto = service.obterCategoria(id);
        model.addAttribute("categoriaDto", categoriaDto);
        return "categoriaatualizar";  // Nome do seu template Thymeleaf
    }

    //-- Atualizar categoria (POST para suportar formulário HTML)
    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id, @ModelAttribute("categoriaDto") CategoriaDto categoriaDto) {
        RespostaDto resposta = service.atualizar(id, categoriaDto);
        return "redirect:/categorialista";  // Ajuste para sua URL real da lista
    }
}
