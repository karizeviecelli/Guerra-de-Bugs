package com.senai.crud.controllers;

import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.ProdutoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/crud")
public class APIProdutoController {

    private final ProdutoService produtoService;

    public APIProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @PostMapping("/produto")
    public ResponseEntity<RespostaDto> cadastrar(@RequestBody ProdutoDto dto) {
        RespostaDto resposta = produtoService.cadastrar(dto);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("produto cadastrado com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
        }
    }

    @DeleteMapping("/produto/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id) {
        RespostaDto resposta = produtoService.excluir(id);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("produto excluído com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }

    @PutMapping("/produto/{id}")
    public ResponseEntity<RespostaDto> atualizar(@PathVariable Long id, @RequestBody ProdutoDto dto) {
        RespostaDto resposta = produtoService.atualizar(id, dto);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("produto atualizado com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }

    @GetMapping("/produto/{id}")
    public ResponseEntity<ProdutoDto> obter(@PathVariable Long id) {
        return ResponseEntity.ok(produtoService.obterProduto(id));
    }

    @GetMapping("/produtos")
    public ResponseEntity<List<ProdutoDto>> listar() {
        return ResponseEntity.ok(produtoService.obterProdutos());
    }

    @GetMapping("/produtos/categoria/{categoriaId}")
    public ResponseEntity<List<ProdutoDto>> listarPorCategoria(@PathVariable Long categoriaId) {
        return ResponseEntity.ok(produtoService.obterProdutosPorCategoria(categoriaId));
    }
}
