package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.loginDto;
import com.senai.CadastroUsuario.models.UsuarioModel;
import com.senai.CadastroUsuario.repositories.UsuarioRepository;
import com.senai.CadastroUsuario.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/crud")
public class LoginController {

    private final UsuarioService service;
    private final UsuarioRepository repository;


    public LoginController(UsuarioService service, UsuarioRepository repository) {
        this.service = service;
        this.repository = repository;
    }

    @GetMapping("/login")
    public String viewLogin(Model model){

        loginDto loginDto = new loginDto();

        model.addAttribute("loginDto",loginDto );


        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("loginDto") loginDto loginDto){

        boolean validacao = service.Login(loginDto);

        if(validacao){

            return "redirect:/home";

        }else{

            return "redirect:/crud/login?erro";
        }
    }

    /*
    @PostMapping("/validarLogin")
    public ResponseEntity <RespostaDto> validarLogin (@RequestBody dtoLogin dados){

        RespostaDto resposta = service.Login(dados);
        return ResponseEntity.ok().body(resposta);
    }

     */
}
