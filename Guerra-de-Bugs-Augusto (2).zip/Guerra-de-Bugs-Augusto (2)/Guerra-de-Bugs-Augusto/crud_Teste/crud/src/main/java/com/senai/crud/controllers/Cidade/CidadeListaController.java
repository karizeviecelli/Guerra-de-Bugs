package com.senai.crud.controllers.Categoria;
import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.CidadeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CidadeListaController {
    private final CidadeService service;

    public CidadeListaController(CidadeService service) {
        this.service = service;
    }

    @GetMapping("/cidadelista")
    public String viewCategoriaLista(Model model){

       // List<CategoriaDto> listaDto=service.obterCategorias();

       // model.addAttribute("listaDto",listaDto);

        return "categorialista";
    }
}
