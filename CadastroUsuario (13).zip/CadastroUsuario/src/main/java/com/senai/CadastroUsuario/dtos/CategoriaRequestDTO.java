package com.senai.CadastroUsuario.dtos;

public class CategoriaRequestDTO {

    private String nome;

    public CategoriaRequestDTO() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
