package com.senai.crud.Crud.services;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.models.CategoriaModel;
import com.senai.crud.Crud.repositories.CategoriaRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    CategoriaRepository repository;

    public CategoriaService(CategoriaRepository repository) {
        this.repository = repository;
    }

    public SaidaDto cadastrarCategoria(CategoriaDto dados) {

        SaidaDto resposta = new SaidaDto();

        CategoriaModel novaCategoria = new CategoriaModel();


        novaCategoria.setNome(dados.getNome());

        repository.save(novaCategoria);


        resposta.setMensagem("Nova categoria cadastrada com sucesso");

        return resposta;

    }

    public List<CategoriaDto> listarCategorias() {

        List<CategoriaDto> listaCategorias = new ArrayList<>();

        List<CategoriaModel> listaDeCategorias = repository.findAll();

        for (CategoriaModel categoria : listaDeCategorias) {
            CategoriaDto categoriaDto = new CategoriaDto();
            categoriaDto.setId(categoria.getId());
            categoriaDto.setNome(categoria.getNome());
            listaCategorias.add(categoriaDto);
        }

        return listaCategorias;
    }

    public CategoriaDto buscarCategoria(Long id) {

        CategoriaDto categoriaDto = new CategoriaDto();

        Optional<CategoriaModel> categoriaOP = repository.findById(id);

        if (categoriaOP.isPresent()) {

            categoriaDto.setId(id);
            categoriaDto.setNome(categoriaOP.get().getNome());

        }

        return categoriaDto;

    }

    public SaidaDto atualizar(Long id, CategoriaDto dados) {

        SaidaDto resposta = new SaidaDto();

        Optional<CategoriaModel> categoriaOP = repository.findById(id);

        if (categoriaOP.isPresent()) {

            CategoriaModel categoriaAtualizada = categoriaOP.get();

            categoriaAtualizada.setId(id);
            categoriaAtualizada.setNome(dados.getNome());

            repository.save(categoriaAtualizada);

            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");
        }

        return resposta;

    }

    public SaidaDto excluir(Long id) {

        SaidaDto resposta = new SaidaDto();

        Optional<CategoriaModel> categoriaOP = repository.findById(id);

        if (categoriaOP.isPresent()) {

            repository.deleteById(id);
            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");

        }
        return resposta;

    }
}