package com.senai.crud.dtos;



public class ContatoDto {
     private Long id;
    private String nome;
    private Long telefone;
    private Long data_de_nascimento;
    private String email;
    private String cidade;

    public ContatoDto() {
    }

    public ContatoDto(Long id, String nome, Long telefone, Long data_de_nascimento, String email, String cidade) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.data_de_nascimento = data_de_nascimento;
        this.email = email;
        this.cidade = cidade;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getTelefone() {
        return telefone;
    }

    public void setTelefone(Long telefone) {
        this.telefone = telefone;
    }

    public Long getData_de_nascimento() {
        return data_de_nascimento;
    }

    public void setData_de_nascimento(Long data_de_nascimento) {
        this.data_de_nascimento = data_de_nascimento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
}
