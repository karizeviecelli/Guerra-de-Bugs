package com.senai.CadastroUsuario.dtos;

public class RespostaDto {

    private String mensagem;

    public RespostaDto() {
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    @Override
    public String toString() {
        return "RespostaDto{" +
                "mensagem='" + mensagem + '\'' +
                '}';
    }
}
