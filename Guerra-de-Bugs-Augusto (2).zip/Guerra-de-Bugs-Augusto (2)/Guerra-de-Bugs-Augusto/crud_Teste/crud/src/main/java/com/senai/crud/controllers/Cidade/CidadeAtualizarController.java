package com.senai.crud.controllers.cidade;

import com.senai.crud.model.Cidade;
import com.senai.crud.services.CidadeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CidadeAtualizarController {

    private final CidadeService cidadeService;

    @Autowired
    public CidadeAtualizarController(CidadeService cidadeService) {
        this.cidadeService = cidadeService;
    }

    /**
     * Exibe o formulário de edição da cidade.
     * Endpoint: GET /cidades/{id}/editar
     */
    @GetMapping("/cidades/{id}/editar")
    public String exibirFormularioEdicao(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        // Busca a cidade pelo ID
        Cidade cidade = cidadeService.buscarPorId(id)
                .orElse(null);

        // Caso não encontre, redireciona com mensagem de erro
        if (cidade == null) {
            redirectAttributes.addFlashAttribute("erro", "Cidade não encontrada!");
            return "redirect:/cidades";
        }

        model.addAttribute("cidade", cidade);
        return "cidade/editar"; // Retorna o template: templates/cidade/editar.html
    }

    /**
     * Atualiza a cidade no banco de dados.
     * Endpoint: POST /cidades/{id}/atualizar
     */
    @PostMapping("/cidades/{id}/atualizar")
    public String atualizarCidade(@PathVariable Long id,
                                  @Valid @ModelAttribute("cidade") Cidade cidade,
                                  BindingResult bindingResult,
                                  RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            // Mantém o formulário aberto se houver erros
            return "cidade/editar";
        }

        // Garante que a cidade tenha o ID correto
        cidade.setId(id);

        // Salva as alterações
        cidadeService.salvar(cidade);

        // Mensagem de sucesso
        redirectAttributes.addFlashAttribute("sucesso", "Cidade atualizada com sucesso!");

        return "redirect:/cidades";
    }
}
