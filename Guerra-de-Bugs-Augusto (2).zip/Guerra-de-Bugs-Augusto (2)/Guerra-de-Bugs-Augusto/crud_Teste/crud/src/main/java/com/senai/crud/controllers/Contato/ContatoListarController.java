package com.senai.crud.controllers;

import com.senai.crud.services.ContatoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ContatoListarController {

    private final ContatoService contatoService;

    @Autowired
    public ContatoListarController(ContatoService contatoService) {
        this.contatoService = contatoService;
    }

    @GetMapping("/contatos/listar")
    public String listarContatos(Model model) {
        model.addAttribute("contatos", contatoService.listarTodos());
        return "contato/listar"; // templates/contato/listar.html
    }
}
