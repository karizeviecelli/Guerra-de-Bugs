package com.senai.crud.controllers;

import com.senai.crud.dtos.LoginDto;
import com.senai.crud.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
    private final UsuarioService usuarioService;

    public LoginController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/login")
    public String viewLogin(Model model){
        //criar um objeto do tipo dto para que o thymeleaf conheça o estrutura
        LoginDto loginDto= new LoginDto();
        // Adicionando a estrutura do dto no model para processamento do html
        model.addAttribute("loginDto",loginDto);

        return "login";
    }


    @PostMapping("/login")
    public String login(@ModelAttribute("loginDto")LoginDto loginDto){
            boolean logar = usuarioService.verifivarLogin(loginDto);
        if (logar){
            //sucesso no login
            return "redirect:/home";
        }else {
            // erro no login
            return"redirect:/login?erro";
        }

    }
}
