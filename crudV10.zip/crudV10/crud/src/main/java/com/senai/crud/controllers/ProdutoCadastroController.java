package com.senai.crud.controllers;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ProdutoCadastroController {

    private final ProdutoService produtoService;
    private final CategoriaService categoriaService;

    public ProdutoCadastroController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    // Mostrar formulário de cadastro
    @GetMapping("/produtocadastro")
    public String viewCadastro(Model model) {
        model.addAttribute("produtoDto", new ProdutoDto()); // objeto vazio para bind do form
        List<CategoriaDto> categorias = categoriaService.obterCategorias();
        model.addAttribute("categorias", categorias); // para preencher o select das categorias
        return "produtocadastro";
    }

    // Receber o POST do formulário
    @PostMapping("/produtocadastro")
    public String cadastrar(ProdutoDto produtoDto) {
        produtoService.cadastrar(produtoDto);
        return "redirect:/produtolista"; // redireciona para a lista após cadastrar
    }
}
