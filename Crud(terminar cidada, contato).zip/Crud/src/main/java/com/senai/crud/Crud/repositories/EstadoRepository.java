package com.senai.crud.Crud.repositories;

import com.senai.crud.Crud.models.EstadoModel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EstadoRepository extends JpaRepository<EstadoModel, Long> {
    Optional<EstadoModel> findBySigla(@NotBlank @NotNull String sigla);
}
