package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.LoginDto;
import com.senai.crud.Crud.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    private final UsuarioService service;

    public LoginController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/login")
    public String viewlogin(Model model) {

        // Criar um objeto DTO para o Thymeleaf reconhecer a estrutura
        LoginDto loginDto = new LoginDto();

        // Adcinando a estrutura DTO no Model
        model.addAttribute("loginDto", loginDto);

        return "login";
    }


    @PostMapping("/login")
    public String login(@ModelAttribute("loginDto") LoginDto loginDto) {

        if (service.autenticarLogin(loginDto)) {
            //sucesso no login

            return "redirect:/home";

        } else {
            //erro no login

            return "redirect:/login?erro";

        }


    }

}
