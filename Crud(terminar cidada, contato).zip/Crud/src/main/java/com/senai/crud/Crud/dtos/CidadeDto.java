package com.senai.crud.Crud.dtos;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CidadeDto {
    @Id
    @GeneratedValue
    private Long id;

    @NotBlank
    @NotNull
    private String cidade;

    @NotBlank
    @NotNull
    private String sigla;

    public CidadeDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotBlank @NotNull String getSigla() {
        return sigla;
    }

    public void setSigla(@NotBlank @NotNull String sigla) {
        this.sigla = sigla;
    }

    public @NotBlank @NotNull String getCidade() {
        return cidade;
    }

    public void setCidade(@NotBlank @NotNull String cidade) {
        this.cidade = cidade;
    }
}
