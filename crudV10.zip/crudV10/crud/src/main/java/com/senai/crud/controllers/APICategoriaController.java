package com.senai.crud.controllers;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.CategoriaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")
public class APICategoriaController {

    private final CategoriaService categoriaService;

    public APICategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @PostMapping("/categoria")
    public ResponseEntity<RespostaDto> cadastrar(@RequestBody CategoriaDto dto) {
        RespostaDto resposta = categoriaService.cadastrar(dto);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("categoria cadastrada com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
        }
    }

    @DeleteMapping("/categoria/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id) {
        RespostaDto resposta = categoriaService.excluir(id);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("categoria excluída com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }

    @PutMapping("/categoria/{id}")
    public ResponseEntity<RespostaDto> atualizar(@PathVariable Long id, @RequestBody CategoriaDto dto) {
        RespostaDto resposta = categoriaService.atualizar(id, dto);
        if ("sucesso".equals(resposta.getMensagem())) {
            resposta.setMensagem("categoria atualizada com sucesso");
            return ResponseEntity.ok(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<CategoriaDto> obter(@PathVariable Long id) {
        return ResponseEntity.ok(categoriaService.obterCategoria(id));
    }

    @GetMapping("/categorias")
    public ResponseEntity<List<CategoriaDto>> listar() {
        return ResponseEntity.ok(categoriaService.obterCategorias());
    }
}

