package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.*;
import com.senai.CadastroUsuario.repositories.ProdutoRepository;
import com.senai.CadastroUsuario.services.ProdutoService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {

    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/produto")
    public String cadastrar(@ModelAttribute("produtoDto") ProdutoRequestDTO produtoDto){

        RespostaDto resposta = service.cadastrarProduto(produtoDto);


        return "redirect:/produtolista";
    }

    @PostMapping("/produto/{id}")
    public String atualizar(@ModelAttribute("produtoDto")ProdutoResponseDTO produtoDTO, @PathVariable Long id){

        RespostaDto resposta = service.alterarProduto(id, produtoDTO);

        return "redirect:/produtolista";
    }

    @DeleteMapping("produto/{id}")
    public ResponseEntity<RespostaDto> deletarProduto(@PathVariable long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
    }
}
