package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.services.CategoriaService;
import com.senai.crud.Crud.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class CategoriaProdutosListaController {

    ProdutoService produtoService;
    CategoriaService categoriaService;

    public CategoriaProdutosListaController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("categoriaprodutos/{id}")
    public String viewCategoriaProdutos(Model model, @PathVariable Long id) {

        List<ProdutoDto> listaProdutoPorCategoria = produtoService.buscarProdutosPorCategoria(id);
        CategoriaDto categoria = categoriaService.buscarCategoria(id);

        model.addAttribute("listaProdutoPorCategoria", listaProdutoPorCategoria);
        model.addAttribute("nomecategoria", categoria.getNome());

        return "categoriaprodutos";

    }

}
