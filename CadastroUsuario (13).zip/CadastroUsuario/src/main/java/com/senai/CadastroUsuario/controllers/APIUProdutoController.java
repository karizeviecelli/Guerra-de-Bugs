package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.*;
import com.senai.CadastroUsuario.services.ProdutoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")
public class APIUProdutoController {

    ProdutoService service;

    public APIUProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/cadastrarProduto")
    public ResponseEntity<RespostaDto> cadastrarProduto(@RequestBody ProdutoRequestDTO dados){

       RespostaDto resposta = service.cadastrarProduto(dados);

       return ResponseEntity.ok().body(resposta);
    }

    @DeleteMapping("deletarProduto/{id}")
    public ResponseEntity<RespostaDto> deletarProduto(@PathVariable long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
    }
    @GetMapping("/listarProdutos")
    public ResponseEntity<List<ProdutoResponseDTO>>listarProdutos(){

        List<ProdutoResponseDTO> resposta = service.ListaProduto();

        return ResponseEntity.ok().body(resposta);
    }
  /*
    @PutMapping("alterarProdutos/{id}")
    public ResponseEntity<RespostaDto> alterarProdutos(@PathVariable long id , @RequestBody ProdutoRequestDTO dados){

        RespostaDto resposta = service.alterarProduto(id , dados);
        return ResponseEntity.ok().body(resposta);
    }

   */

    @GetMapping("pesquisarProduto/{id}")
    public ResponseEntity<ProdutoResponseDTO> pesquisarProduto(@PathVariable long id){

        ProdutoResponseDTO resposta = service.pesquisaProduto(id);

        return ResponseEntity.ok().body(resposta);
    }

    /*

    @GetMapping("ProdutosDeCategoria/{id}")
    public ResponseEntity<List<ProdutoResponseDTO>> ProdutosDeCategoria(@PathVariable long id){

        List<ProdutoResponseDTO> resposta = service.listaProdutoCategoria(id);

        return ResponseEntity.ok().body(resposta);
    }

     */
}
