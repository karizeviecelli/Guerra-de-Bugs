package com.senai.crud.Crud.dtos;

public class SaidaDto {

    private String mensagem = "";

    public SaidaDto() {
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}
