package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.RequisicaoDto;
import com.senai.CadastroUsuario.dtos.RespostaDto;
import com.senai.CadastroUsuario.dtos.UsuarioDto;
import com.senai.CadastroUsuario.services.UsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService serivice) {
        this.service = serivice;
    }

    @PostMapping("/usuario")
    public String cadastrar(@ModelAttribute("usuarioDto") RequisicaoDto usuarioDto){

       RespostaDto resposta = service.Cadastrar(usuarioDto);


        return "redirect:/usuariolista";
    }

    @PostMapping("/usuario/{id}")
    public String atualizar(@ModelAttribute("usuarioDto") UsuarioDto usuarioDto , @PathVariable Long id){

       RespostaDto resposta = service.alterar(id,usuarioDto );

        return "redirect:/usuariolista";
    }

    @DeleteMapping("usuario/{id}")
    public ResponseEntity<RespostaDto> deletar(@PathVariable Long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
    }
}
