package com.senai.crud.controllers;

import com.senai.crud.model.Cidade;
import com.senai.crud.services.CidadeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/cidades")
public class CidadeController {

    private final CidadeService cidadeService;

    @Autowired
    public CidadeController(CidadeService cidadeService) {
        this.cidadeService = cidadeService;
    }

    // 🔹 LISTAR TODAS AS CIDADES
    @GetMapping
    public String listarCidades(Model model) {
        model.addAttribute("cidades", cidadeService.listarTodas());
        return "cidade/listar"; // templates/cidade/listar.html
    }

    // 🔹 ABRIR FORMULÁRIO DE CADASTRO
    @GetMapping("/nova")
    public String abrirFormularioCadastro(Model model) {
        if (!model.containsAttribute("cidade")) {
            model.addAttribute("cidade", new Cidade());
        }
        return "cidade/cadastrar"; // templates/cidade/cadastrar.html
    }

    // 🔹 SALVAR NOVA CIDADE
    @PostMapping
    public String salvarCidade(@Valid @ModelAttribute("cidade") Cidade cidade,
                               BindingResult bindingResult,
                               RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.cidade", bindingResult);
            redirectAttributes.addFlashAttribute("cidade", cidade);
            return "redirect:/cidades/nova";
        }

        cidadeService.salvar(cidade);
        redirectAttributes.addFlashAttribute("sucesso", "Cidade cadastrada com sucesso!");
        return "redirect:/cidades";
    }

    // 🔹 ABRIR FORMULÁRIO DE EDIÇÃO
    @GetMapping("/{id}/editar")
    public String editarCidade(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<CidadeController> cidadeOpt = cidadeService.buscarPorId(id);
        if (cidadeOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("erro", "Cidade não encontrada!");
            return "redirect:/cidades";
        }
        model.addAttribute("cidade", cidadeOpt.get());
        return "cidade/editar"; // templates/cidade/editar.html
    }

    // 🔹 ATUALIZAR CIDADE
    @PostMapping("/{id}/atualizar")
    public String atualizarCidade(@PathVariable Long id,
                                  @Validated @ModelAttribute("cidade") CidadeController cidade,
                                  BindingResult bindingResult,
                                  RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "cidade/editar";
        }

        cidade.setId(id);
        cidadeService.equals(cidade);
        redirectAttributes.addFlashAttribute("sucesso", "Cidade atualizada com sucesso!");
        return "redirect:/cidades";
    }

    // 🔹 EXCLUIR CIDADE
    @GetMapping("/{id}/excluir")
    public String excluirCidade(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Optional<Cidade> cidadeOpt = cidadeService.equals(id);

        if (cidadeOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("erro", "Cidade não encontrada!");
        } else {
            cidadeService.excluir(id);
            redirectAttributes.addFlashAttribute("sucesso", "Cidade excluída com sucesso!");
        }

        return "redirect:/cidades";
    }
}
