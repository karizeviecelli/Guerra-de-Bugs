package com.senai.crud.controllers.Estado;

import com.senai.crud.dtos.EstadoDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.EstadoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.*;

@Controller
public class EstadoController {
    private final EstadoService service;

    public EstadoController(EstadoService service) {
        this.service = service;
    }

    @PostMapping("/estado")
    public String cadastrar(@ModelAttribute("estadoDto")EstadoDto estadoDto){
        RespostaDto mensagem = service.cadastrar(estadoDto);
        return "redirect:/estadolista";
    }
    @PostMapping("/estado/{id}")
    public String atualizar(@ModelAttribute("estadoDto") EstadoDto estadoDto, @PathVariable Long id){

        service.atualizar(id,estadoDto);

        return "redirect:/estadolista";
    }

    @DeleteMapping("/estado/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){

        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("estado excluido com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }
}
