package com.senai.crud.controllers.Categoria;

import com.senai.crud.dtos.CategoriaDto;

import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.CategoriaService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.*;

@Controller
public class CategoriaController {
    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping("/categoria")
    public String cadastrar(@ModelAttribute("categoriaDto")CategoriaDto categoriaDto){
        RespostaDto mensagem = service.cadastrar(categoriaDto);
        return "redirect:/categorialista";
    }
    @PostMapping("/categoria/{id}")
    public String atualizar(@ModelAttribute("categoriaDto") CategoriaDto categoriaDto, @PathVariable Long id){

        service.atualizar(id,categoriaDto);

        return "redirect:/categorialista";
    }
    @DeleteMapping("/categoria/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){

        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("Categoria excluida com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }
}
