package com.senai.crud.controllers;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.dtos.RespostaDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/categorias")
public class CategoriaProdutoController {

    private final CategoriaService categoriaService;
    private final ProdutoService produtoService;

    public CategoriaProdutoController(CategoriaService categoriaService, ProdutoService produtoService) {
        this.categoriaService = categoriaService;
        this.produtoService = produtoService;
    }

    // Listar todas as categorias
    @GetMapping
    public String listarCategorias(Model model) {
        List<CategoriaDto> categorias = categoriaService.obterCategorias();
        model.addAttribute("categorias", categorias);
        return "categorias/lista";  // ex: src/main/resources/templates/categorias/lista.html
    }

    // Listar produtos de uma categoria específica
    @GetMapping("/{id}/produtos")
    public String listarProdutosPorCategoria(@PathVariable Long id, Model model) {
        CategoriaDto categoria = categoriaService.obterCategoria(id);

        if (categoria == null || categoria.getId() == null) {
            return "redirect:/categorias?erro=naoencontrado";
        }

        List<ProdutoDto> produtos = produtoService.obterProdutosPorCategoria(id);
        model.addAttribute("categoria", categoria);
        model.addAttribute("produtos", produtos);

        return "produtos/listaPorCategoria";  // ex: src/main/resources/templates/produtos/listaPorCategoria.html
    }

    // Excluir categoria
    @GetMapping("/excluir/{id}")
    public String excluirCategoria(@PathVariable Long id) {
        categoriaService.excluir(id);
        return "redirect:/categorias";
    }
}
