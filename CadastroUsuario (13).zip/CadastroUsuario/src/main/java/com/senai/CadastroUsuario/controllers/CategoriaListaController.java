package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.ProdutoResponseDTO;
import com.senai.CadastroUsuario.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CategoriaListaController {

    private final CategoriaService service;

    public CategoriaListaController(CategoriaService service) {
        this.service = service;
    }

    @GetMapping("/categorialista")
    public String listapCategoria(Model model){

        List<CategoriaResponseDTO> listagemDto = service.listarCategoria();
        model.addAttribute("listagemDto" , listagemDto);
        return "categorialista";
    }
}
