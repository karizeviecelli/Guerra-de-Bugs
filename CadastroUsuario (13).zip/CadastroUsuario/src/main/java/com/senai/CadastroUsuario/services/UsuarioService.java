package com.senai.CadastroUsuario.services;

import com.senai.CadastroUsuario.dtos.*;
import com.senai.CadastroUsuario.models.Categoria;
import com.senai.CadastroUsuario.models.Produto;
import com.senai.CadastroUsuario.models.UsuarioModel;
import com.senai.CadastroUsuario.repositories.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

  Long contadorCategoria = 0l;
  Long contadorProduto = 0l;

    List<UsuarioModel> ListaUsuario = new ArrayList<UsuarioModel>();
    List<Categoria> ListaCategoria = new ArrayList<Categoria>();
    List<Produto> ListaProduto = new ArrayList<Produto>();

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public RespostaDto Cadastrar(RequisicaoDto dados){

        UsuarioModel usuario = new UsuarioModel();
        RespostaDto resposta = new RespostaDto();

        usuario.setNome(dados.getNome());
        usuario.setLogin(dados.getLogin());
        usuario.setSenha(dados.getSenha());

        repository.save(usuario);

        ListaUsuario.add(usuario);
        resposta.setMensagem("Cadastrado com Sucesso");
        return resposta ;


    }

    public RespostaDto deletar(Long id){

      //  UsuarioModel usuario = new UsuarioModel();
        RespostaDto resposta = new RespostaDto();

        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if(usuarioOP.isPresent()){

            // Significa que encontrou o usuario pelo id
            repository.delete(usuarioOP.get());

            resposta.setMensagem("Usuario deletado com sucesso");

            return resposta;
        }
        resposta.setMensagem("Usuario nao existe");
        return resposta;
    }

    public RespostaDto alterar(Long id, RequisicaoDto dados) {

        RespostaDto resposta = new RespostaDto();

        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if(usuarioOP.isPresent()){

            // Obtem o usuarioModel de dentro do Opcional
            UsuarioModel usuario = usuarioOP.get();
            usuario.setNome(dados.getNome());
            usuario.setLogin(dados.getLogin());
            usuario.setSenha(dados.getSenha());

            repository.save(usuario);
            resposta.setMensagem("Usuário alterado com sucesso");
            return resposta;
        }

        resposta.setMensagem("Usuário não existe");
        return resposta;
    }

    public RespostaDto alterar(Long id, UsuarioDto dados) {

        RespostaDto resposta = new RespostaDto();

        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if(usuarioOP.isPresent()){

            // Obtem o usuarioModel de dentro do Opcional
            UsuarioModel usuario = usuarioOP.get();
            usuario.setNome(dados.getNome());
            usuario.setLogin(dados.getLogin());
            usuario.setSenha(dados.getSenha());

            repository.save(usuario);
            resposta.setMensagem("Usuário alterado com sucesso");
            return resposta;
        }

        resposta.setMensagem("Usuário não existe");
        return resposta;
    }

    public List<UsuarioDto> listar(){

        List<UsuarioDto> listaResposta = new ArrayList<>();

        RespostaDto resposta = new RespostaDto();

        List<UsuarioModel> listaUsuarioModel = repository.findAll();

        for(UsuarioModel lista : listaUsuarioModel){
            UsuarioDto usuario = new UsuarioDto();
           usuario.setId(lista.getId());
           usuario.setNome(lista.getNome());
           usuario.setLogin(lista.getLogin());
           usuario.setSenha(lista.getSenha());


          listaResposta.add(usuario);

        }
        return listaResposta;
      }

    public UsuarioDto pesquisaTeste(Long id) {

        UsuarioDto resposta = new UsuarioDto();
     Optional<UsuarioModel> usuario0p = repository.findById(id);

     if(usuario0p.isPresent()){

         resposta.setId(usuario0p.get().getId());
         resposta.setNome(usuario0p.get().getNome());
         resposta.setLogin(usuario0p.get().getLogin());
         resposta.setSenha(usuario0p.get().getSenha());

         return resposta;
     }

     return resposta;

    }

    public boolean Login (loginDto loginDto ){
        Optional<UsuarioModel> usuario =  repository.findByLoginAndSenha(loginDto.getLogin() , loginDto.getSenha());

        if(usuario.isPresent()){

            return true;
        }

         return false;
    }






}
