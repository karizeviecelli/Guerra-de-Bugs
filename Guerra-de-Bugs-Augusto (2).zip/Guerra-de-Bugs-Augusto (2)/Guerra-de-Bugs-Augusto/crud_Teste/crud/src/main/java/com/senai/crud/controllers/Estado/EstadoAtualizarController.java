package com.senai.crud.controllers.Categoria;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.EstadoDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.EstadoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class EstadoAtualizarController {

    private final EstadoService service;

    public EstadoAtualizarController(EstadoService service) {
        this.service = service;
    }

    @GetMapping("/estadoatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        EstadoDto estadoDto = service.obterEstado(id);
        model.addAttribute("estadoDto",estadoDto);
        return "estadoatualizar";
    }
}
