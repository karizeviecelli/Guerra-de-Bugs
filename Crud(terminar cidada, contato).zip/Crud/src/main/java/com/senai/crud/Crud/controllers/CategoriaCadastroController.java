package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoriaCadastroController {

    @GetMapping("/categoriacadastro")
    public String viewCategoriaCadastro(Model model) {

        model.addAttribute("categoriaDto", new CategoriaDto());

        return "categoriacadastro";
    }
}
