package com.senai.crud.controllers.Produto;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.ProdutoDto;
import com.senai.crud.dtos.UsuarioDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.ProdutoService;
import com.senai.crud.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ProdutoAtualizarController {

    private final ProdutoService service;
    private final CategoriaService categoriaService;

    public ProdutoAtualizarController(ProdutoService service, CategoriaService categoriaService) {
        this.service = service;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/produtoatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        List<CategoriaDto> categoriasDto = categoriaService.obterCategorias();
        ProdutoDto produtoDto = service.obterProduto(id);
        model.addAttribute("produtoDto",produtoDto);
        model.addAttribute("categoriasDto",categoriasDto);
        return "produtoatualizar";
    }
}
