package com.senai.crud.controllers.Estado;

import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.EstadoDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EstadoCadastroController {
    @GetMapping("/estadocadastro")
    public String viewCadastro(Model model){

        model.addAttribute("estadoDto",new EstadoDto());



        return "estadocadastro";
    }
}
