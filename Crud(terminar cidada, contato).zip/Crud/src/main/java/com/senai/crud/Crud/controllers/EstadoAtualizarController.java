package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.EstadoDto;
import com.senai.crud.Crud.services.EstadoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class EstadoAtualizarController {

    EstadoService estadoService;

    public EstadoAtualizarController(EstadoService estadoService) {
        this.estadoService = estadoService;
    }

    @GetMapping("/estadoatualizar/{id}")
    public String viewEstadoAtualizar(Model model, @PathVariable Long id) {


        EstadoDto estadoDto = estadoService.buscarEstadoPorId(id);

        model.addAttribute("estadoDto", estadoDto);

        return "estadoatualizar";

    }
}
