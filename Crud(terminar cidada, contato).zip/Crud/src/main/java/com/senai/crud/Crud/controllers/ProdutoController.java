package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.ProdutoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {

    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/produto")
    public String cadastrar(@ModelAttribute("produtoDto") ProdutoDto produtoDto) {

        SaidaDto resposta = service.cadatrarProduto(produtoDto);

        return "redirect:/produtolista";

    }


    @PostMapping("/produto/{id}")
    public String atualizar(@ModelAttribute("produtoDto") ProdutoDto produtoDto, @PathVariable Long id) {

        SaidaDto saidaDto = service.atualizarProduto(id, produtoDto);

        return "redirect:/produtolista";
    }

    @DeleteMapping("/produto/{id}")
    public ResponseEntity<SaidaDto> exluirProduto(@PathVariable Long id) {
        SaidaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            return ResponseEntity.ok().body(resposta);

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }
}
