package com.senai.crud.services;

import org.springframework.stereotype.Service;

@Service
public class ContatoService {
}
