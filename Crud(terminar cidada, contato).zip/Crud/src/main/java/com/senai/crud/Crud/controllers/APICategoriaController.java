package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.CategoriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")

public class APICategoriaController {

    private final CategoriaService service;

    public APICategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping("/categorias")
    public ResponseEntity<SaidaDto> cadastrarCategorias(@RequestBody CategoriaDto dados) {

        SaidaDto resposta = service.cadastrarCategoria(dados);

        return ResponseEntity.ok().body(resposta);

    }

    @GetMapping("/categorias")
    public ResponseEntity<List<CategoriaDto>> listarCategorias() {

        return ResponseEntity.ok().body(service.listarCategorias());

    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<CategoriaDto> bucarCategoriaPorId(@PathVariable Long id) {

        CategoriaDto categoria = service.buscarCategoria(id);

        return ResponseEntity.ok().body(categoria);
    }


    @PutMapping("/categoria/{id}")
    public ResponseEntity<SaidaDto> atualizar(@PathVariable Long id, @RequestBody CategoriaDto dados) {

        SaidaDto resposta = service.atualizar(id, dados);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("Categoria atualizada");

        } else {
            resposta.setMensagem(("Não foi possivel atualiza categoria"));
        }

        return ResponseEntity.ok().body(resposta);
    }

    @DeleteMapping("/categoria/{id}")
    public ResponseEntity<SaidaDto> excluir(@PathVariable Long id) {
        SaidaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("Categoria exluida");

        } else {
            resposta.setMensagem("Não foi possivel exluir cateoria");
        }
        return ResponseEntity.ok().body(resposta);

    }


}
