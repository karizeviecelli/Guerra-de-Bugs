package com.senai.crud.Crud.services;

import com.senai.crud.Crud.dtos.CidadeDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.models.CidadeModel;
import com.senai.crud.Crud.models.EstadoModel;
import com.senai.crud.Crud.repositories.CidadeRepository;
import com.senai.crud.Crud.repositories.EstadoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CidadeService {

    private final CidadeRepository cidadeRepository;
    private final EstadoRepository estadoRepository;

    public CidadeService(CidadeRepository cidadeRepository, EstadoRepository estadoRepository) {
        this.cidadeRepository = cidadeRepository;
        this.estadoRepository = estadoRepository;
    }

    public boolean cadastrarCidade(CidadeDto cidadeDto) {

        Optional<EstadoModel> estadoModelOptional = estadoRepository.findBySigla(cidadeDto.getSigla());

        if (estadoModelOptional.isEmpty()) {
            return false;
        }

        CidadeModel novaCidade = new CidadeModel();

        novaCidade.setNome(cidadeDto.getCidade());
        novaCidade.setEstado(estadoModelOptional.get());

        cidadeRepository.save(novaCidade);
        return true;

    }

    public SaidaDto excluirCidade(Long id) {

        SaidaDto saidaDto = new SaidaDto();
        Optional<CidadeModel> cidadeModelOptional = cidadeRepository.findById(id);

        if (cidadeModelOptional.isPresent()) {
            cidadeRepository.delete(cidadeModelOptional.get());

            saidaDto.setMensagem("sucesso");

            return saidaDto;
        } else {

            return saidaDto;
        }

    }

    public List<CidadeDto> listarCidades() {

        List<CidadeModel> cidadeModelList = cidadeRepository.findAll();

        List<CidadeDto> listaCidades = new ArrayList<>();
        for (CidadeModel cidadeModel : cidadeModelList) {

            CidadeDto cidadeDto = new CidadeDto();

            cidadeDto.setId(cidadeModel.getId());
            cidadeDto.setCidade(cidadeModel.getNome());
            cidadeDto.setSigla(cidadeModel.getEstado().getSigla());

            listaCidades.add(cidadeDto);

        }

        return listaCidades;
    }

    public boolean atualizarCidade(Long id, CidadeDto cidadeDto) {

        Optional<CidadeModel> cidadeModelOptional = cidadeRepository.findById(id);
        Optional<EstadoModel> estadoModelOptional = estadoRepository.findBySigla(cidadeDto.getSigla());

        if (cidadeModelOptional.isEmpty()) {
            return false;
        }

        if (estadoModelOptional.isEmpty()) {
            return false;
        }

        CidadeModel cidadeModel = cidadeModelOptional.get();

        cidadeModel.setNome(cidadeDto.getCidade());
        cidadeModel.setEstado(estadoModelOptional.get());
        cidadeRepository.save(cidadeModel);

        return true;


    }

    public CidadeDto buscarCidadePorId(Long id) {
        CidadeDto cidadeDto = new CidadeDto();
        Optional<CidadeModel> cidadeModelOptional = cidadeRepository.findById(id);

        if (cidadeModelOptional.isPresent()) {

            cidadeDto.setId(cidadeModelOptional.get().getId());
            cidadeDto.setCidade(cidadeModelOptional.get().getNome());
            cidadeDto.setSigla(cidadeModelOptional.get().getEstado().getSigla());
            return cidadeDto;

        } else {

            return cidadeDto;
        }

    }


}
