package com.senai.crud.Crud.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class ContatoController {
}
