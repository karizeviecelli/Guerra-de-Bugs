package com.senai.crud.Crud.services;

import com.senai.crud.Crud.dtos.EntradaDto;
import com.senai.crud.Crud.dtos.LoginDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.dtos.UsuarioDto;
import com.senai.crud.Crud.models.UsuarioModel;
import com.senai.crud.Crud.repositories.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public SaidaDto cadastrar(EntradaDto dados) {

        SaidaDto resposta = new SaidaDto();

        UsuarioModel user = new UsuarioModel();

        user.setNome(dados.getNome());
        user.setLogin(dados.getLogin());
        user.setSenha(dados.getSenha());

        repository.save(user);

        resposta.setMensagem("sucesso");

        return resposta;
    }

    public List<UsuarioDto> listarUsuarios() {

        List<UsuarioDto> listaDeUsuariosDto = new ArrayList<>();

        List<UsuarioModel> listaUsuariosModel = repository.findAll();

        for (UsuarioModel user : listaUsuariosModel) {

            UsuarioDto usuarioDto = new UsuarioDto();

            usuarioDto.setId(user.getId());
            usuarioDto.setNome(user.getNome());
            usuarioDto.setLogin(user.getLogin());
            usuarioDto.setSenha(user.getSenha());

            listaDeUsuariosDto.add(usuarioDto);
        }

        return listaDeUsuariosDto;
    }

    public UsuarioDto buscarUsuario(Long id) {

        Optional<UsuarioModel> usuarioOp = repository.findById(id);
        UsuarioDto usuarioDto = new UsuarioDto();


        if (usuarioOp.isPresent()) {


            usuarioDto.setId(usuarioOp.get().getId());
            usuarioDto.setNome(usuarioOp.get().getNome());
            usuarioDto.setLogin(usuarioOp.get().getLogin());
            usuarioDto.setSenha(usuarioOp.get().getSenha());


        }
        return usuarioDto;


    }

    public SaidaDto atualizar(Long id, EntradaDto dados) {

        SaidaDto resposta = new SaidaDto();

        Optional<UsuarioModel> usuarioOp = repository.findById(id);

        if (usuarioOp.isPresent()) {
            UsuarioModel user = usuarioOp.get();

            user.setId(id);
            user.setNome(dados.getNome());
            user.setLogin(dados.getLogin());
            user.setSenha(dados.getSenha());

            repository.save(user);

            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");

        }

        return resposta;

    }

    public SaidaDto atualizar(Long id, UsuarioDto dados) {

        SaidaDto resposta = new SaidaDto();

        Optional<UsuarioModel> usuarioOp = repository.findById(id);

        if (usuarioOp.isPresent()) {
            UsuarioModel user = usuarioOp.get();

            user.setId(id);
            user.setNome(dados.getNome());
            user.setLogin(dados.getLogin());
            user.setSenha(dados.getSenha());

            repository.save(user);

            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");

        }

        return resposta;

    }


    public SaidaDto excluirUsuario(Long id) {

        SaidaDto resposta = new SaidaDto();

        Optional<UsuarioModel> usuarioOp = repository.findById(id);

        if (usuarioOp.isPresent()) {

            repository.delete(usuarioOp.get());
            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");

        }

        return resposta;

    }


    public boolean autenticarLogin(LoginDto loginDto) {

        Optional<UsuarioModel> userOp = repository.findByLoginAndSenha(loginDto.getLogin(), loginDto.getSenha());

        if (userOp.isPresent()) {
            return true;

        }
        return false;

    }
}

