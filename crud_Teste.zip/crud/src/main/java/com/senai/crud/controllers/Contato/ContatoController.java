package com.senai.crud.controllers.Contato;

public class ContatoController {
}
