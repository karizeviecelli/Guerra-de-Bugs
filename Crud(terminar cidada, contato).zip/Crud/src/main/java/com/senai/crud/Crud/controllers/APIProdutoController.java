package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.ProdutoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crud")
public class APIProdutoController {

    private ProdutoService service;

    public APIProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/produtos")
    public ResponseEntity<SaidaDto> cadastrarProduto(@RequestBody ProdutoDto dados) {

        SaidaDto resposta = service.cadatrarProduto(dados);

        return ResponseEntity.ok().body(resposta);
    }

    @GetMapping("/produtos")
    public ResponseEntity<List<ProdutoDto>> listarProdutos() {

        return ResponseEntity.ok().body(service.listarProdutos());
    }

    @GetMapping("/produto/categoria/{id}")
    public ResponseEntity<List<ProdutoDto>> buscarProdutosPorCategoria(@PathVariable Long id) {

        return ResponseEntity.ok().body(service.buscarProdutosPorCategoria(id));


    }

    @DeleteMapping("/produto/{id}")
    public ResponseEntity<SaidaDto> exluirProduto(@PathVariable Long id) {
        SaidaDto resposta = service.excluir(id);

        return ResponseEntity.ok().body(resposta);
    }


    @PutMapping("/produto/{id}")
    public ResponseEntity<SaidaDto> atualizarProduto(@PathVariable Long id, @RequestBody ProdutoDto dados) {

        SaidaDto resposta = service.atualizarProduto(id, dados);

        return ResponseEntity.ok().body(resposta);
    }
}

