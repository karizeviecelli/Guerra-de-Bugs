package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.UsuarioDto;
import com.senai.crud.Crud.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class UsuarioListaController {

    private final UsuarioService service;

    public UsuarioListaController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/usuariolista")
    public String viewUsuarioLista(Model model) {

        //Carregar Lista com os usuários
        List<UsuarioDto> listaDto = service.listarUsuarios();

        //Adiciona lista no Model
        model.addAttribute("listaDto", listaDto);

        return "/usuarioLista";

    }
}
