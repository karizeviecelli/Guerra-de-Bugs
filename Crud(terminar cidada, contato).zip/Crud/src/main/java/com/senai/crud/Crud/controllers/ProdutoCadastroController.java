package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ProdutoCadastroController {


    private final CategoriaService service;

    public ProdutoCadastroController(CategoriaService service) {
        this.service = service;
    }

    @GetMapping("/produtocadastro")
    public String viewProdutoCadastro(Model model) {

        List<CategoriaDto> listaCategorias = service.listarCategorias();

        model.addAttribute("produtoDto", new ProdutoDto());
        model.addAttribute("listaCategoria", listaCategorias);

        return "produtocadastro";
    }
}
