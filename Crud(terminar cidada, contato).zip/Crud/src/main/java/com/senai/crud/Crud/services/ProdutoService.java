package com.senai.crud.Crud.services;

import com.senai.crud.Crud.dtos.ProdutoDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.models.CategoriaModel;
import com.senai.crud.Crud.models.ProdutoModel;
import com.senai.crud.Crud.repositories.CategoriaRepository;
import com.senai.crud.Crud.repositories.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {


    ProdutoRepository produtoRepository;
    CategoriaRepository categoriaRepository;

    public ProdutoService(ProdutoRepository produtoRepository, CategoriaRepository categoriaRepository) {
        this.produtoRepository = produtoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    public SaidaDto cadatrarProduto(ProdutoDto dados) {

        SaidaDto resposta = new SaidaDto();
        ProdutoModel novoProduto = new ProdutoModel();

        Optional<CategoriaModel> categoriaOp = categoriaRepository.findById(dados.getCategoriaId());

        if (categoriaOp.isPresent()) {

            novoProduto.setNome(dados.getNome());
            novoProduto.setPreco(dados.getPreco());
            novoProduto.setCategoria(categoriaOp.get());

            produtoRepository.save(novoProduto);

            resposta.setMensagem("Novo produto cadastrado");
            return resposta;

        } else {
            resposta.setMensagem("Categoria não existe");
        }
        return resposta;
    }

    public List<ProdutoDto> listarProdutos() {

        List<ProdutoDto> listaProdutosDto = new ArrayList<>();

        List<ProdutoModel> listadeProdutos = produtoRepository.findAll();

        for (ProdutoModel produto : listadeProdutos) {
            ProdutoDto produtoDto = new ProdutoDto();

            produtoDto.setId(produto.getId());
            produtoDto.setNome(produto.getNome());
            produtoDto.setPreco(produto.getPreco());
            produtoDto.setCategoriaId(produto.getCategoria().getId());
            produtoDto.setCategoriaNome(produto.getCategoria().getNome());

            listaProdutosDto.add(produtoDto);

        }

        return listaProdutosDto;
    }

    public List<ProdutoDto> buscarProdutosPorCategoria(Long id) {

        List<ProdutoDto> listaProdutosPorCategoria = new ArrayList<>();

        List<ProdutoModel> listaDeProdutosModel = produtoRepository.findByCategoriaId(id);

        for (ProdutoModel produto : listaDeProdutosModel) {
            ProdutoDto produtoDto = new ProdutoDto();

            produtoDto.setId(produto.getId());
            produtoDto.setNome(produto.getNome());
            produtoDto.setPreco(produto.getPreco());
            produtoDto.setCategoriaId(produto.getCategoria().getId());
            produtoDto.setCategoriaNome(produto.getCategoria().getNome());

            listaProdutosPorCategoria.add(produtoDto);

        }


        return listaProdutosPorCategoria;
    }

    public SaidaDto excluir(Long id) {

        SaidaDto resposta = new SaidaDto();

        Optional<ProdutoModel> produtoOP = produtoRepository.findById(id);

        if (produtoOP.isPresent()) {
            produtoRepository.deleteById(id);
            resposta.setMensagem("sucesso");
        } else {
            resposta.setMensagem("erro");
        }
        return resposta;

    }

    public SaidaDto atualizarProduto(Long id, ProdutoDto dados) {

        SaidaDto resposta = new SaidaDto();

        Optional<ProdutoModel> produtoOp = produtoRepository.findById(id);
        Optional<CategoriaModel> categoriaOp = categoriaRepository.findById(dados.getCategoriaId());

        if (produtoOp.isPresent() && categoriaOp.isPresent()) {


            ProdutoModel novoProduto = produtoOp.get();

            novoProduto.setId(id);
            novoProduto.setNome(dados.getNome());
            novoProduto.setPreco(dados.getPreco());
            novoProduto.setCategoria(categoriaOp.get());
            produtoRepository.save(novoProduto);
            resposta.setMensagem("sucesso");

        } else {
            resposta.setMensagem("erro");
        }
        return resposta;

    }

    public ProdutoDto buscarProduto(Long id) {

        Optional<ProdutoModel> produto = produtoRepository.findById(id);

        if (produto.isEmpty()) {
            return null;
        }

        ProdutoDto produtoDto = new ProdutoDto();
        produtoDto.setId(produto.get().getId());
        produtoDto.setNome(produto.get().getNome());
        produtoDto.setPreco(produto.get().getPreco());
        produtoDto.setCategoriaId(produto.get().getCategoria().getId());

        return produtoDto;

    }
}
