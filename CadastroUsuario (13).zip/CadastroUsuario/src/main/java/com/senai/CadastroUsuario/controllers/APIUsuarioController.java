package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.*;
import com.senai.CadastroUsuario.services.UsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/crud")
public class APIUsuarioController {

    UsuarioService service;

    public APIUsuarioController(UsuarioService service) {
        this.service = service;
    }
    @PostMapping("/Cadastrar")
    public ResponseEntity<RespostaDto> Cadastrar (@RequestBody RequisicaoDto dados){
        RespostaDto resposta = service.Cadastrar(dados);
      return ResponseEntity.ok().body(resposta);
  }
  @DeleteMapping("deletar/{id}")
  public ResponseEntity<RespostaDto> deletar( @PathVariable Long id){

        RespostaDto resposta = service.deletar(id);
        return ResponseEntity.ok().body(resposta);
  }
  @PutMapping("alterar/{id}")
  public ResponseEntity<RespostaDto> alterar (@PathVariable Long id ,@RequestBody RequisicaoDto dados){

        RespostaDto resposta = service.alterar(id , dados);

        return ResponseEntity.ok().body(resposta);
  }
  /*
    @GetMapping("listaTodos")
    public ResponseEntity<List<UsuarioDto>> listaTodos() {
        List<UsuarioDto> resposta = service.listar();
        return ResponseEntity.ok(resposta);
    }

   */

    @GetMapping("pesquisaTest/{id}")
    public ResponseEntity<UsuarioDto> pesquisaTest(@PathVariable Long id){
        UsuarioDto resposta = service.pesquisaTeste(id);
        return ResponseEntity.ok().body(resposta);
    }
}

