package com.senai.crud.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/contatos")
public class ContatoController {
    // Controlador principal para redirecionar
    @RequestMapping
    public String redirecionarParaLista() {
        return "redirect:/contatos/listar";
    }
}
