package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.ProdutoResponseDTO;
import com.senai.CadastroUsuario.dtos.UsuarioDto;
import com.senai.CadastroUsuario.services.CategoriaService;
import com.senai.CadastroUsuario.services.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class produtoAtualizarController {

    private final ProdutoService service;
    private final CategoriaService seiveceCategoria;

    public produtoAtualizarController(ProdutoService service, CategoriaService seiveceCategoria) {
        this.service = service;
        this.seiveceCategoria = seiveceCategoria;
    }



    @GetMapping("/produtoatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        List<CategoriaResponseDTO> categoriasDto = seiveceCategoria.listarCategoria();
        ProdutoResponseDTO produtoDto = service.pesquisaProduto(id);
        model.addAttribute("produtoDto" , produtoDto);
        model.addAttribute("categoriasDto" , categoriasDto);

        return "produtoatualizar";
    }
}
