package com.senai.crud.controllers.Cidade;

public class CidadeCadastroController {
}
