package com.senai.crud.Crud.services;

import org.springframework.stereotype.Service;

@Service
public class ContatoService {


}
