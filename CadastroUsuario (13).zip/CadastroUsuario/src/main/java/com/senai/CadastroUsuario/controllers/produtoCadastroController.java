package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.ProdutoRequestDTO;
import com.senai.CadastroUsuario.dtos.RequisicaoDto;
import com.senai.CadastroUsuario.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class produtoCadastroController {

    private final CategoriaService service;

    public produtoCadastroController(CategoriaService service) {
        this.service = service;
    }



    @GetMapping("/produtocadastro")
        public String viewCadastro(Model model){

        List<CategoriaResponseDTO> categoriasDto = service.listarCategoria();

            model.addAttribute("produtoDto" ,new ProdutoRequestDTO());
            model.addAttribute("categoriasDto" , categoriasDto);

            return "produtocadastro";

    }
}
