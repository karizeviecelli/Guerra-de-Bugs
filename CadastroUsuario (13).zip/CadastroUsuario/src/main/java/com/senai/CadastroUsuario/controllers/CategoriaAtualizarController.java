package com.senai.CadastroUsuario.controllers;

import com.senai.CadastroUsuario.dtos.CategoriaResponseDTO;
import com.senai.CadastroUsuario.dtos.ProdutoResponseDTO;
import com.senai.CadastroUsuario.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class CategoriaAtualizarController {

    private final CategoriaService service;

    public CategoriaAtualizarController(CategoriaService service) {
        this.service = service;
    }

    @GetMapping("/categoriaatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        CategoriaResponseDTO categoriaDto = service.pesquisaCategoria(id);
        model.addAttribute("categoriaDto" , categoriaDto);

        return "categoriaatualizar";
    }
}
