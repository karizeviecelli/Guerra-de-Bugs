package com.senai.crud.Crud.models;

import jakarta.persistence.*;

@Entity
@Table(name = "contato")
public class ContatoModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public ContatoModel() {
    }
}
