package com.senai.crud.controllers.Categoria;
import com.senai.crud.dtos.CategoriaDto;
import com.senai.crud.dtos.EstadoDto;
import com.senai.crud.services.CategoriaService;
import com.senai.crud.services.EstadoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class EstadoListaController {
    private final EstadoService service;

    public EstadoListaController(EstadoService service) {
        this.service = service;
    }

    @GetMapping("/estadolista")
    public String viewCategoriaLista(Model model){

        List<EstadoDto> listaDto=service.obterEstado();

        model.addAttribute("listaDto",listaDto);

        return "estadolista";
    }
}
