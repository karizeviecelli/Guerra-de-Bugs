package com.senai.crud.Crud.controllers;


import com.senai.crud.Crud.dtos.CidadeDto;
import com.senai.crud.Crud.services.CidadeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CidadeListaController {

    CidadeService cidadeService;

    public CidadeListaController(CidadeService cidadeService) {
        this.cidadeService = cidadeService;
    }

    @GetMapping("/cidadelista")
    public String viewCidadeLista(Model model) {

        List<CidadeDto> listaCidadeDtoList = cidadeService.listarCidades();

        model.addAttribute("cidadeLista", listaCidadeDtoList);

        return "cidadelista";

    }
}
