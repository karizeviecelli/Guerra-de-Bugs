package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.EstadoDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.EstadoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EstadoController {

    EstadoService estadoService;

    public EstadoController(EstadoService estadoService) {
        this.estadoService = estadoService;
    }

    @PostMapping("/estado")
    public String cadastrarEstado(EstadoDto estadoDto) {

        boolean cadastro = estadoService.cadastrarEstado(estadoDto);

        return "redirect:/estadolista";


    }


    @DeleteMapping("/estado/{id}")
    public ResponseEntity<SaidaDto> exluirEstado(@PathVariable Long id) {

        SaidaDto resposta = estadoService.excluirEstado(id);

        if (resposta.getMensagem().equals("sucesso")) {
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }


    }


    @PostMapping("estado/{id}")
    public String atualizarEstado(@ModelAttribute("estadoDto") EstadoDto estadoDto, @PathVariable Long id) {

        estadoService.atualizarEstado(id, estadoDto);

        return "redirect:/estadolista";
    }


}
