package com.senai.crud.Crud.controllers;

import com.senai.crud.Crud.dtos.CategoriaDto;
import com.senai.crud.Crud.dtos.SaidaDto;
import com.senai.crud.Crud.services.CategoriaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CategoriaController {

    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping("categoria")
    public String cadastrarCategoria(@ModelAttribute("categoriaDto") CategoriaDto categoriaDto) {

        SaidaDto resposta = service.cadastrarCategoria(categoriaDto);

        return "redirect:/categorialista";
    }

    @PostMapping("/categoria/{id}")
    public String atualizarCategoria(@ModelAttribute("categoriaDto") CategoriaDto categoriaDto, @PathVariable Long id) {

        SaidaDto saidaDto = service.atualizar(id, categoriaDto);

        return "redirect:/categorialista";
    }

    @DeleteMapping("/categoria/{id}")
    public ResponseEntity<SaidaDto> exluirCategoria(@PathVariable Long id) {
        SaidaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {

            return ResponseEntity.ok().body(resposta);

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }
    }
}
